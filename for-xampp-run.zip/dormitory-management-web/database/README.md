# database/

Thư mục chứa các file liên quan đến cơ sở dữ liệu.

## Các file

### `db.sql`
Schema SQL của toàn bộ database `QuanLyKTX`. Bao gồm lệnh `CREATE TABLE` cho các bảng:
- `Student` — Thông tin sinh viên
- `Room` — Thông tin phòng KTX
- `Contract` — Hợp đồng thuê phòng
- `UtilityBill` — Hóa đơn điện nước
- `Notice` — Thông báo nội bộ

Để khởi tạo database từ đầu, chạy:
```bash
mysql -u root -p < database/db.sql
```

### `seed.php`
Script tạo dữ liệu giả (fake data) theo chuẩn PTIT:
- **Mã SV**: `B[21-25]DC[mã ngành][3 số ngẫu nhiên]` — VD: `B23DCCN024`
- **Email**: `[tên][chữ cái đầu họ/đệm]@stu.ptit.edu.vn`
- **SĐT**: `[03/08/09][8 chữ số]`
- **Ngành**: CNTT, ATTT, KHMT, ĐTVT, TTNT, Marketing, Kế toán, TMĐT...

Để chạy seed (cần server đang chạy hoặc kết nối DB trực tiếp):
```bash
php database/seed.php
```

Script nhận số lượng bản ghi tùy chỉnh và tự động tạo dữ liệu liên kết giữa các bảng theo thứ tự: Room → Student → Contract → UtilityBill → Notice.
