# views/dashboard/

## `index.php`
Trang tổng quan hệ thống. Hiển thị:
- **3 thẻ thống kê**: Tổng sinh viên · Phòng trống · Hóa đơn chưa thu
- **Biểu đồ cột** doanh thu theo 12 tháng (dùng Chart.js)

Nhận biến từ `DashboardController`:
- `$stats` — mảng thống kê
- `$monthlyRevenue` — mảng 12 phần tử doanh thu theo tháng (được JSON encode sang JS)
