# views/layout/

Thư mục chứa các **partial template** dùng chung cho toàn bộ ứng dụng.

## Các file

### `header.php`
Phần đầu HTML bao gồm: `<head>` (meta, CSS, fonts), mở `<body>`, `<div class="app-container">`, include sidebar, mở `<main>` và `<header>` top-bar.

Nhận biến `$pageTitle` để hiển thị tiêu đề trang ở top-bar.

### `footer.php`
Đóng tất cả thẻ HTML đã mở trong `header.php`. Include `/public/js/main.js`.

### `sidebar.php`
Thanh điều hướng bên trái. Tự động tính `$controller` từ URI (`$_SERVER['REQUEST_URI']`) để highlight menu đang active.

Menu items: Tổng quan · Sinh viên · Phòng KTX · Hợp đồng · Hóa đơn · Thông báo.

### `pagination.php`
Component phân trang dùng chung. Nhận các biến:
- `$total_pages` — tổng số trang
- `$page` — trang hiện tại
- `$search` — từ khóa tìm kiếm (để giữ khi chuyển trang)

Tự động đọc tên controller từ URI để build URL phân trang đúng cho từng module.

Chỉ render nếu `$total_pages > 1`.
