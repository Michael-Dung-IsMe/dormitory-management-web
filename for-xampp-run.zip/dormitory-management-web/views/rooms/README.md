# views/rooms/

View CRUD cho module **Phòng KTX**.

## Các file

### `index.php`
Danh sách phòng với: số phòng, tầng, loại phòng, sức chứa, số người đang ở, trạng thái.

### `create.php`
Form thêm phòng. Dropdown **Loại phòng** nhận các giá trị ENUM từ DB:
- `4 người` (mặc định)
- `6 người`
- `8 người`

### `edit.php`
Form chỉnh sửa. Nhận biến `$room` (object Room). Dropdown Loại phòng dùng `selected` so sánh với `$room->room_type`.

Form action: `POST /room/edit/{id}`.
