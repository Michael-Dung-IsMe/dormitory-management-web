# views/students/

View CRUD cho module **Sinh viên**.

## Các file

### `index.php`
Danh sách sinh viên với:
- Thanh tìm kiếm theo tên / mã SV
- Bảng dữ liệu: mã SV, họ tên, ngày sinh, SĐT, email, khoa, trạng thái
- Nút Thêm, Sửa, Xóa
- Component phân trang (`views/layout/pagination.php`)

Biến nhận vào: `$students` (array), `$page`, `$total_pages`, `$search`.

### `create.php`
Form thêm sinh viên mới. Các trường: mã SV, họ tên, ngày sinh, SĐT, email, khoa, trạng thái.

### `edit.php`
Form chỉnh sửa. Nhận biến `$student` (object Student) — các trường được điền sẵn giá trị hiện tại.

Form action: `POST /student/edit/{id}`.
