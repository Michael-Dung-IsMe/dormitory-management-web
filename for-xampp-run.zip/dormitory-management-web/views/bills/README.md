# views/bills/

View CRUD cho module **Hóa đơn tiện ích** (điện, nước, phòng).

## Các file

### `index.php`
Danh sách hóa đơn: số phòng, tháng/năm, chỉ số điện/nước, tổng tiền, trạng thái, ngày thanh toán.

### `create.php`
Form tạo hóa đơn mới. Nhập chỉ số điện/nước cũ và mới. Tổng tiền được tính tự động bởi model (`calculateTotal()`).

Validate: chỉ số mới phải ≥ chỉ số cũ (kiểm tra ở Controller).

### `edit.php`
Form chỉnh sửa hóa đơn. Thêm trường `payment_date` để cập nhật ngày thanh toán khi đổi trạng thái sang `Đã thanh toán`.

### `export.php`
Trang in/xuất hóa đơn dạng printable. Không có header/sidebar — layout riêng biệt. Truy cập qua `GET /bill/export/{id}`.
