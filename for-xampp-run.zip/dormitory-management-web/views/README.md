# views/

Thư mục chứa tầng **View** trong kiến trúc MVC. Mỗi module có thư mục con riêng. View nhận dữ liệu từ Controller qua biến PHP (`$students`, `$room`, `$contract`...) và render HTML.

## Cấu trúc

```
views/
├── layout/         — Các partial dùng chung (header, footer, sidebar, pagination)
├── dashboard/      — Trang tổng quan
├── students/       — CRUD sinh viên
├── rooms/          — CRUD phòng
├── contracts/      — CRUD hợp đồng
├── bills/          — CRUD hóa đơn + trang xuất
└── notices/        — CRUD thông báo
```

## Pattern chung

Mỗi thư mục module thường có 3 file:
| File | Mục đích |
|------|----------|
| `index.php` | Danh sách + tìm kiếm + phân trang |
| `create.php` | Form thêm mới |
| `edit.php` | Form chỉnh sửa (dữ liệu được điền sẵn từ Controller) |

Mỗi View bắt đầu bằng `include 'views/layout/header.php'` và kết thúc bằng `include 'views/layout/footer.php'`.

## Lưu ý đường dẫn

Tất cả đường dẫn tới CSS/JS/ảnh phải dùng dấu `/` ở đầu (đường dẫn tuyệt đối từ gốc):
```html
<!-- ✅ Đúng -->
<link rel="stylesheet" href="/public/css/style.css">

<!-- ❌ Sai (vỡ layout ở URL nhiều cấp như /student/edit/1) -->
<link rel="stylesheet" href="public/css/style.css">
```
