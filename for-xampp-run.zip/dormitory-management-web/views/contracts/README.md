# views/contracts/

View CRUD cho module **Hợp đồng**.

## Các file

### `index.php`
Danh sách hợp đồng kèm JOIN: tên sinh viên, số phòng, ngày bắt đầu/kết thúc, tiền thuê, đặt cọc, trạng thái.

### `create.php`
Form tạo hợp đồng mới. Dropdown chọn sinh viên và phòng từ DB.

### `edit.php`
Form chỉnh sửa. Nhận biến `$contract` (object Contract), `$students` (array), `$rooms` (array).

Dropdown sinh viên và phòng giữ nguyên giá trị đang chọn (`selected` so sánh với `$contract->student_id` và `$contract->room_id`).

Form action: `POST /contract/edit/{id}`.

Trạng thái hợp đồng: `Đang ở` · `Đã chuyển ra` · `Đã hủy`.
