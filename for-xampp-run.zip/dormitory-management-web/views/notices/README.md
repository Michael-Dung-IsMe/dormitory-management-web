# views/notices/

View CRUD cho module **Thông báo nội bộ**.

## Các file

### `index.php`
Danh sách thông báo: loại đối tượng, phòng/sinh viên liên quan, nội dung, ngày tạo. Sắp xếp theo ngày mới nhất.

### `create.php`
Form tạo thông báo. Dropdown **Loại đối tượng**:
- `Toàn trường` — không cần chọn phòng/SV
- `Theo phòng` — chọn phòng từ dropdown
- `Theo sinh viên` — chọn sinh viên từ dropdown

### `edit.php`
Form chỉnh sửa thông báo. Nhận biến `$notice` (object Notice), `$rooms` (array), `$students` (array).

Cho phép cập nhật lại ngày thông báo (`$notice->date`).
