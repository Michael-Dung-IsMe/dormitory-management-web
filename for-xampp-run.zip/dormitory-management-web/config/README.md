# config/

Thư mục chứa cấu hình toàn cục của ứng dụng.

## Các file

### `database.php`
> ⚠️ File này được thêm vào `.gitignore` — không được commit lên repository.

Chứa class `Database` với Singleton Pattern, đảm bảo chỉ tạo đúng **một** kết nối PDO duy nhất trong toàn bộ request:

```php
Database::getConnection(); // Trả về $conn, tái sử dụng nếu đã có
```

Thông số cấu hình nằm trong các static property (`$host`, `$db_name`, `$port`, `$username`, `$password`). Cần cập nhật phù hợp với môi trường local/production.

### `routes.php`
File đăng ký tất cả route của ứng dụng. Được `index.php` `require` sau khi khởi tạo `$router`.

Cú pháp:
```php
$router->get('/student',           'StudentController@index');
$router->get('/student/edit/{id}', 'StudentController@edit');
$router->post('/student/create',   'StudentController@create');
```

Các nhóm route hiện có:
- `/` → Dashboard
- `/student` → Sinh viên (CRUD)
- `/room` → Phòng KTX (CRUD)
- `/contract` → Hợp đồng (CRUD)
- `/bill` → Hóa đơn tiện ích (CRUD + export)
- `/notice` → Thông báo (CRUD)
