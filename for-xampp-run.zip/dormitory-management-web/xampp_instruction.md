# Hướng dẫn Cài đặt & Chạy Dự án với XAMPP

Tài liệu này cung cấp các bước chi tiết để chạy dự án **Quản lý Ký túc xá** hoàn toàn trên môi trường XAMPP (Apache + MySQL) trên hệ điều hành Windows.

## 1. Yêu cầu hệ thống
- Đã cài đặt phần mềm **XAMPP** (bao gồm Apache và MySQL).
- Dự án đã được sao chép vào máy tính.

---

## 2. Thiết lập Apache & Virtual Host (Khuyên dùng)
Việc sử dụng Virtual Host (Tên miền ảo) giúp dự án chạy ở địa chỉ `http://dormitory.local`, ngăn chặn lỗi với các đường dẫn tuyệt đối (ví dụ: `/auth/login` hay các file css, js).

### Bước 2.1: Cấu hình Virtual Host
1. Mở thư mục cài đặt XAMPP, tìm đến tệp:
   `C:\xampp\apache\conf\extra\httpd-vhosts.conf`
2. Mở tệp tin này bằng trình chỉnh sửa văn bản (Notepad, VSCode,...) và thêm đoạn sau vào **cuối tệp**:
   ```apache
   <VirtualHost *:80>
       DocumentRoot "D:/projects/dormitory-management-web"
       ServerName dormitory.local
       <Directory "D:/projects/dormitory-management-web">
           Options Indexes FollowSymLinks
           AllowOverride All
           Require all granted
       </Directory>
   </VirtualHost>
   ```
   *(Lưu ý: Thay đổi đường dẫn `D:/projects/dormitory-management-web` thành đường dẫn thực tế chứa mã nguồn của bạn nếu có khác biệt).*

### Bước 2.2: Cấu hình File Hosts của Windows
1. Nhấn nút Windows, tìm kiếm **Notepad**.
2. Click chuột phải vào Notepad và chọn **Run as administrator** (Chạy với quyền quản trị).
3. Chọn File -> Open, dán đường dẫn sau vào ô File name:
   `C:\Windows\System32\drivers\etc\hosts`
4. Thêm dòng sau vào **cuối tệp**:
   ```text
   127.0.0.1 dormitory.local
   ```
5. Lưu lại (Ctrl + S).

---

## 3. Thiết lập Cơ sở dữ liệu MySQL

### Bước 3.1: Xử lý Xung đột Port (QUAN TRỌNG)
Nếu trên máy bạn đã cài sẵn MySQL (chạy ở cổng 3306) và gây xung đột khiến MySQL của XAMPP không thể khởi động, bạn cần **đổi cổng MySQL của XAMPP**:

1. Mở XAMPP Control Panel, tại dòng MySQL nhấn **Config** -> **my.ini**.
2. Tìm kiếm `port=3306` và đổi tất cả thành `port=3307`. Lưu file lại.
3. Cấu hình lại phpMyAdmin để sử dụng cổng mới:
   - Mở tệp: `C:\xampp\phpMyAdmin\config.inc.php`
   - Tìm dòng `$cfg['Servers'][$i]['host'] = '127.0.0.1';`
   - Thêm dòng cấu hình cổng ngay bên dưới:
     ```php
     $cfg['Servers'][$i]['port'] = '3307';
     ```
4. Cập nhật mã nguồn dự án:
   - Mở file `config/database.php`
   - Đảm bảo cấu hình cổng là: `private static $port = 3307;`

### Bước 3.2: Nhập (Import) Dữ liệu
1. Mở **XAMPP Control Panel**, nhấn **Start** cho **Apache** và **MySQL**.
2. Mở trình duyệt web, truy cập địa chỉ: `http://localhost/phpmyadmin`
3. Nhấn **New** (Tạo mới) ở danh sách bên trái.
   - Nhập tên cơ sở dữ liệu: `QuanLyKTX`
   - Bảng mã (Collation): `utf8mb4_general_ci`
   - Nhấn **Create** (Tạo).
4. Chọn cơ sở dữ liệu `QuanLyKTX` vừa tạo.
5. Chuyển sang tab **Import** (Nhập) ở phía trên.
6. Nhấn **Choose File** (Chọn tệp) và tìm đến tệp:
   `database\db.sql` (nằm trong thư mục dự án của bạn).
7. Cuộn xuống dưới cùng và nhấn **Import** (hoặc Go) để thực thi.

*(Tùy chọn) Chạy dữ liệu mẫu:*
Mở Powershell/CMD và chạy lệnh sau (thay đường dẫn cho phù hợp):
```bash
C:\xampp\php\php.exe D:\projects\dormitory-management-web\database\seed.php
```

---

## 4. Chạy & Trải nghiệm
Sau khi hoàn tất các bước trên:
- Hãy đảm bảo **Apache** và **MySQL** trên XAMPP đang chạy xanh.
- Mở trình duyệt và truy cập: [http://dormitory.local](http://dormitory.local)
- Hệ thống sẽ hoạt động 100% bằng XAMPP với đầy đủ các tính năng.
