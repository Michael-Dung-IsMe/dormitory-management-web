# core/

Thư mục này chứa các class nền tảng (foundation) của kiến trúc MVC, được load tự động bởi `index.php` trước khi bất kỳ Controller hay Model nào được khởi tạo.

## Các file

### `Router.php`
Class điều hướng request HTTP. Hoạt động theo cơ chế:
1. Nhận `$_SERVER['REQUEST_URI']` và `$_SERVER['REQUEST_METHOD']`
2. So khớp URI với danh sách route đã đăng ký trong `config/routes.php`
3. Hỗ trợ tham số động dạng `{id}` — được convert sang regex `(?P<id>[a-zA-Z0-9_-]+)` và inject vào `$_GET`
4. Nếu không khớp route nào → trả về HTTP 404

Hai method công khai:
- `get($route, 'Controller@action')` — đăng ký route GET
- `post($route, 'Controller@action')` — đăng ký route POST

### `BaseController.php`
Class cha mà tất cả 5 Controller kế thừa (`extends BaseController`).

Cung cấp method `paginate(int $limit = 25): array` — đọc `$_GET['page']` và `$_GET['search']`, trả về mảng:
```php
['search' => ..., 'page' => ..., 'limit' => ..., 'offset' => ...]
```
Tránh lặp lại cùng một khối code pagination ở mọi Controller.

### `BaseModel.php`
Class cha mà tất cả 5 Model kế thừa (`extends BaseModel`).

Mỗi Model con chỉ cần khai báo 5 thuộc tính cấu hình:
| Thuộc tính | Mô tả | Ví dụ |
|---|---|---|
| `$tableClause` | Tên bảng (có thể kèm alias) | `'Student'`, `'Room r'` |
| `$selectClause` | Phần SELECT | `'*'`, `'c.*, s.full_name'` |
| `$joinClause` | Mệnh đề JOIN | `'JOIN Room r ON ...'` |
| `$searchColumns` | Mảng cột áp dụng LIKE search | `['full_name', 'student_code']` |
| `$orderBy` | Thứ tự sắp xếp | `'student_id DESC'` |

Cung cấp 2 method dùng chung:
- `count(string $search): int` — đếm tổng bản ghi (dùng cho pagination)
- `read(string $search, int $limit, int $offset)` — trả về PDOStatement để fetch
