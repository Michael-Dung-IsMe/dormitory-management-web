# controllers/

Thư mục chứa tầng **Controller** trong kiến trúc MVC. Controller nhận request từ Router, gọi Model để xử lý dữ liệu, rồi load View tương ứng.

## Kế thừa

Tất cả Controller đều `extends BaseController` (`core/BaseController.php`) để tái sử dụng method `paginate()`.

```
BaseController  (core/BaseController.php)
├── DashboardController
├── StudentController
├── RoomController
├── ContractController
├── BillController
└── NoticeController
```

## Luồng hoạt động chung

```
Router → new XxxController() → gọi action() → load View
```

Dữ liệu được truyền từ Controller vào View thông qua **biến PHP** (`$students`, `$rooms`, `$contract`...). View không dùng `$this->model->field`.

## Các file

### `DashboardController.php`
Action duy nhất: `index()`. Truy vấn thống kê (tổng SV, phòng trống, hóa đơn chưa thu) và dữ liệu doanh thu theo tháng cho biểu đồ Chart.js.

### `StudentController.php`
CRUD sinh viên. Method `edit()` truyền `$student = $this->student` ra view.

### `RoomController.php`
CRUD phòng KTX. Method `edit()` truyền `$room = $this->room` ra view.

### `ContractController.php`
CRUD hợp đồng. Cần load thêm `Student` và `Room` model để tạo dropdown chọn SV/phòng. Validate: phòng chưa đầy, SV chưa có hợp đồng active.

### `BillController.php`
CRUD hóa đơn tiện ích. Có thêm action `export()` để render trang in hóa đơn. Validate: chỉ số mới ≥ chỉ số cũ.

### `NoticeController.php`
CRUD thông báo nội bộ. Hỗ trợ 3 loại đối tượng: toàn trường, theo phòng, theo sinh viên.
