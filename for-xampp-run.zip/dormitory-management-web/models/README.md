# models/

Thư mục chứa tầng **Model** trong kiến trúc MVC. Mỗi Model đại diện cho một bảng trong database và xử lý toàn bộ tương tác với CSDL (CRUD).

## Kế thừa

Tất cả Model đều `extends BaseModel` (`core/BaseModel.php`). Nhờ đó, hai method `count()` và `read()` dùng cho danh sách & phân trang được kế thừa sẵn — Model con không cần viết lại.

```
BaseModel  (core/BaseModel.php)
├── Student
├── Room
├── Contract
├── UtilityBill
└── Notice
```

## Các file

### `Student.php`
Bảng `Student`. Tìm kiếm theo `full_name`, `student_code`. Sắp xếp theo `student_id DESC`.

### `Room.php`
Bảng `Room r`. SELECT bao gồm subquery đếm số sinh viên đang ở (`current_occupancy`). Tìm kiếm theo `r.room_number`. Sắp xếp theo tầng và số phòng.

### `Contract.php`
Bảng `Contract c`. JOIN với `Student` và `Room` để hiển thị tên SV và số phòng. Tìm kiếm theo tên SV, mã SV, hoặc số phòng.

### `UtilityBill.php`
Bảng `UtilityBill b`. JOIN với `Room`. Ngoài CRUD, có thêm method `calculateTotal()` tính tổng tiền từ chỉ số điện/nước/phòng. Tìm kiếm theo số phòng, tháng, năm.

### `Notice.php`
Bảng `Notice n`. LEFT JOIN với cả `Room` và `Student` (nullable). Tìm kiếm theo nội dung, loại thông báo, phòng, sinh viên. Sắp xếp theo ngày tạo mới nhất.

## Cấu trúc method chung

| Method | Mô tả |
|--------|-------|
| `count($search)` | Đếm tổng bản ghi (kế thừa từ BaseModel) |
| `read($search, $limit, $offset)` | Lấy danh sách có phân trang (kế thừa từ BaseModel) |
| `readOne()` | Lấy 1 bản ghi theo ID (định nghĩa trong từng Model) |
| `create()` | Thêm mới bản ghi |
| `update()` | Cập nhật bản ghi |
| `delete()` | Xóa bản ghi |
