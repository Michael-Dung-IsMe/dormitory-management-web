# Kịch Bản Kiểm Thử (Test Scenarios)
**Độ bao phủ dự kiến:** ~85% (Bao gồm các luồng CRUD cơ bản, logic nghiệp vụ lõi và quy trình hàng tháng).

---

## Kịch bản 1: Luồng Quản lý Dữ liệu Nền tảng (Sinh viên & Phòng KTX)
**Mục tiêu:** Đảm bảo hệ thống có thể lưu trữ, cập nhật và hiển thị chính xác các thực thể cơ bản nhất, làm nền tảng cho các nghiệp vụ sau.

**Các bước thực hiện:**
1. **Thêm Sinh viên:** Truy cập module Sinh viên -> Chọn "Thêm mới" -> Nhập đầy đủ thông tin (Mã SV, Họ tên, Ngày sinh, Giới tính, Quê quán, SĐT, Email, Khóa, Ngành học). -> *Lưu*.
2. **Tìm kiếm:** Ra màn hình danh sách, gõ Mã SV hoặc Tên vừa nhập vào ô tìm kiếm. -> *Xác nhận dữ liệu hiển thị đúng*.
3. **Thêm Phòng KTX:** Truy cập module Phòng KTX -> Chọn "Thêm mới" -> Nhập số phòng (VD: 101), Tầng 1, Khu A, Sức chứa tối đa (VD: 4 người), Giá phòng/tháng. -> *Lưu*.
4. **Cập nhật:** Chỉnh sửa giá phòng hoặc sức chứa của phòng vừa tạo.

**Kết quả mong đợi:**
- Dữ liệu Sinh viên và Phòng được lưu chính xác vào Database.
- Công cụ tìm kiếm và phân trang hoạt động đúng.
- Tại danh sách phòng, `current_occupancy` (Số lượng hiện tại) của phòng mới tạo phải hiển thị là **0**.

---

## Kịch bản 2: Luồng Nghiệp vụ Cốt lõi (Xếp phòng & Hợp đồng)
**Mục tiêu:** Kiểm thử các ràng buộc logic khắt khe của hệ thống khi ghép sinh viên vào phòng KTX.

**Các bước thực hiện:**
1. **Tạo Hợp đồng mới:** Truy cập module Hợp đồng -> "Thêm mới" -> Chọn Sinh viên và Phòng vừa tạo ở Kịch bản 1. Nhập ngày bắt đầu và kết thúc. -> *Lưu*.
2. **Kiểm tra trạng thái phòng:** Quay lại màn hình danh sách Phòng KTX. -> *Xác nhận `current_occupancy` của phòng đã tăng lên **1***.
3. **Test Validation - Sinh viên trùng lặp:** Quay lại module Hợp đồng -> Cố gắng tạo thêm 1 hợp đồng mới cho **chính Sinh viên đó** (vẫn đang trong hạn hợp đồng).
4. **Test Validation - Phòng đầy:** Tạo thêm các hợp đồng cho phòng đó cho đến khi `current_occupancy` đạt mức "Sức chứa tối đa" (VD: 4/4). Sau đó, cố gắng thêm người thứ 5 vào phòng.

**Kết quả mong đợi:**
- Hợp đồng hợp lệ được lưu thành công, số lượng người trong phòng tự động cập nhật.
- **Hệ thống chặn (báo lỗi)** khi cố gắng tạo hợp đồng cho sinh viên đã có phòng.
- **Hệ thống chặn (báo lỗi)** khi cố gắng gán sinh viên vào phòng đã đạt sức chứa tối đa.

---

## Kịch bản 3: Luồng Nghiệp vụ Định kỳ (Tính Tiền Điện Nước & Thông báo)
**Mục tiêu:** Đảm bảo hệ thống tính toán tài chính chính xác và truyền đạt thông tin đúng đối tượng.

**Các bước thực hiện:**
1. **Tạo Hóa đơn:** Truy cập module Hóa đơn -> "Thêm mới" -> Chọn phòng đã có người ở (từ Kịch bản 2), chọn Tháng/Năm hiện tại.
2. **Test Validation - Chỉ số:** Nhập "Chỉ số điện mới" **nhỏ hơn** "Chỉ số điện cũ". -> *Hệ thống phải báo lỗi*.
3. **Tính tổng tiền:** Nhập đúng chỉ số mới lớn hơn chỉ số cũ. -> *Lưu*.
4. **Kiểm tra phép tính:** Mở xem chi tiết hóa đơn vừa tạo. Tính nhẩm: `(Số điện tiêu thụ x Đơn giá điện) + (Số nước x Đơn giá) + Giá phòng`. -> *Xác nhận tổng tiền hệ thống tính khớp 100%*.
5. **Gửi Thông báo:** Truy cập module Thông báo -> "Thêm mới" -> Loại thông báo: "Theo phòng" -> Chọn đúng phòng vừa tạo hóa đơn. Nội dung: "Yêu cầu thanh toán hóa đơn tháng này".

**Kết quả mong đợi:**
- Không cho phép nhập sai lệch chỉ số điện nước.
- Hệ thống tự động tính toán tổng số tiền chính xác tuyệt đối.
- Có thể xuất/in hóa đơn.
- Thông báo được lưu thành công và chỉ nhắm tới đúng phòng KTX được chỉ định.
